create definer = root@localhost trigger after_user_info_insert
    after insert
    on user_info
    for each row
BEGIN 
INSERT INTO user_info_backup VALUES(new.user_id,new.first_name,new.last_name,new.email,new.password,new.mobile,new.address1,new.address2);
END;

