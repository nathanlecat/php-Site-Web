create
    definer = root@localhost procedure getcat(IN cid int)
SELECT * FROM categories WHERE cat_id=cid;

